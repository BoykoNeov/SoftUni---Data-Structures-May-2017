﻿/// <summary>
/// Linked list Launcher
/// </summary>
public class Launcher
{
    public static void Main()
    {
        
    }
}