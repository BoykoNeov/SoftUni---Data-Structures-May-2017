﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using UnitTests;

/// <summary>
/// Runs the unit tests without requiring the Visual Studio test framework.
/// </summary>
class Program
{
    /// <summary>
    /// Entry point for the program.
    /// </summary>
    public static void Main()
    {
        LeftLeaningRedBlackTreeTest test = new LeftLeaningRedBlackTreeTest();
        VerifyExpectedException(() => test.NullKeyComparer(), typeof(ArgumentNullException));
        VerifyExpectedException(() => test.NullValueComparer(), typeof(ArgumentNullException));
        VerifyExpectedException(() => test.RemoveKeyMultiple(), typeof(InvalidOperationException));
        VerifyExpectedException(() => test.GetValueForKeyMultiple(), typeof(InvalidOperationException));
        VerifyExpectedException(() => test.GetValueForMissingKey(), typeof(KeyNotFoundException));
        test.RandomScenariosNormalStatic();
        test.RandomScenariosMultipleStatic();
        test.RandomScenariosNormalVariable();
        test.RandomScenariosMultipleVariable();
    }

    /// <summary>
    /// Verify the expected exception is thrown.
    /// </summary>
    /// <param name="action">Action to perform.</param>
    /// <param name="exception">Type of expected exception.</param>
    [SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes", Justification = "Simple test helper.")]
    private static void VerifyExpectedException(Action action, Type exception)
    {
        try
        {
            action();
            throw new Exception("Missing exception.");
        }
        catch (Exception e)
        {
            if (e.GetType() != exception)
            {
                throw new Exception("Wrong exception type.");
            }
        }
    }
}

// Stub classes
namespace Microsoft.VisualStudio.TestTools.UnitTesting
{
    sealed class TestClass : Attribute { }
    sealed class TestMethod : Attribute { }
    sealed class ExpectedException : Attribute
    {
        [SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "t", Justification = "Matching existing API.")]
        public ExpectedException(Type t) { }
    }
    sealed class Description : Attribute
    {
        [SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "s", Justification = "Matching existing API.")]
        public Description(string s) { }
    }
}

/// <summary>
/// Trivial implementation of necessary Assert methods.
/// </summary>
static class Assert
{
    [SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes", Justification = "Stub for unit testing methods.")]
    public static void IsTrue(bool value)
    {
        if (!value)
        {
            throw new Exception("!IsTrue");
        }
    }
    [SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes", Justification = "Stub for unit testing methods.")]
    public static void IsFalse(bool value)
    {
        if (value)
        {
            throw new Exception("!IsFalse");
        }
    }
    [SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes", Justification = "Stub for unit testing methods.")]
    public static void AreEqual<T>(T x, T y)
    {
        if (!object.Equals(x, y))
        {
            throw new Exception("!AreEqual");
        }
    }
}
