﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Controls.DataVisualization.Collections;

namespace SideBySideComparison
{
    /// <summary>
    /// Measures performance of similar algorithms side-by-side.
    /// </summary>
    class Program
    {
        /// <summary>
        /// Entry point for the program.
        /// </summary>
        /// <param name="args">Arguments.</param>
        public static void Main(string[] args)
        {
            // Prepare list of iterations
            var maximum = 2000;
            var increment = 100;
            if (1 <= args.Length)
            {
                maximum = int.Parse(args[0]);
                if (2 <= args.Length)
                {
                    increment = int.Parse(args[1]);
                }
            }

            // Output headers
            var iterations = new List<int>();
            // Prime the pump (ex: JIT methods) with the first iteration - then throw it away
            iterations.Add(1000);
            for (var i = 0; i <= maximum; i += increment)
            {
                iterations.Add(i);
                Console.Write("," + i);
            }
            Console.WriteLine();
            Debug.WriteLine("Type,Iterations,Add,Extremes,Remove,Ordered Scenario,Random Scenario");

            // Output BinaryTree results
            Console.Write("BinaryTree");
            var first = true;
            foreach (var iteration in iterations)
            {
                var binaryTree = new BinaryTree<int, int>(
                    (left, right) => left.CompareTo(right),
                    (left, right) => left.CompareTo(right));
                var scenario = RunScenarios(
                    "BinaryTree",
                    iteration,
                    (k, v) => binaryTree.Add(k, v),
                    (k, v) => binaryTree.Remove(k, v),
                    () => binaryTree.MinimumKey + binaryTree.MaximumKey);
                if (!first)
                {
                    Console.Write("," + scenario.Ticks);
                }
                first = false;
            }
            Console.WriteLine();

            // Output LeftLeaningRedBlackTree results
            Console.Write("LeftLeaningRedBlackTree");
            first = true;
            foreach (var iteration in iterations)
            {
                var leftLeaningRedBlackTree = new LeftLeaningRedBlackTree<int, int>(
                    (left, right) => left.CompareTo(right),
                    (left, right) => left.CompareTo(right));
                var scenario = RunScenarios(
                    "LeftLeaningRedBlackTree",
                    iteration,
                    (k, v) => leftLeaningRedBlackTree.Add(k, v),
                    (k, v) => leftLeaningRedBlackTree.Remove(k, v),
                    () => leftLeaningRedBlackTree.MinimumKey + leftLeaningRedBlackTree.MaximumKey);
                if (!first)
                {
                    Console.Write("," + scenario.Ticks);
                }
                first = false;
            }
            Console.WriteLine();
        }

        /// <summary>
        /// Runs the specified performance scenario.
        /// </summary>
        /// <param name="name">Class being tested.</param>
        /// <param name="iterations">Number of iterations to run.</param>
        /// <param name="add">Action to add a pair.</param>
        /// <param name="remove">Action to remove a pair.</param>
        /// <param name="extremes">Action to fetch extreme values.</param>
        /// <returns>Elapsed time for primary scenario.</returns>
        private static TimeSpan RunScenarios(string name, int iterations, Action<int, int> add, Action<int, int> remove, Func<int> extremes)
        {
            Debug.Write(name + "," + iterations);

            // Time adding
            Stopwatch stopwatchAdd = new Stopwatch();
            stopwatchAdd.Start();
            for (var i = 0; i < iterations; i++)
            {
                add(i, i);
            }
            stopwatchAdd.Stop();
            Debug.Write("," + stopwatchAdd.Elapsed.Ticks);

            // Time extremes
            Stopwatch stopwatchExtremes = new Stopwatch();
            stopwatchExtremes.Start();
            for (var i = 0; i < iterations; i++)
            {
                int x = extremes();
            }
            stopwatchExtremes.Stop();
            Debug.Write("," + stopwatchExtremes.Elapsed.Ticks);

            // Time removing
            Stopwatch stopwatchRemove = new Stopwatch();
            stopwatchRemove.Start();
            for (var i = 0; i < iterations; i++)
            {
                remove(i, i);
            }
            stopwatchRemove.Stop();
            Debug.Write("," + stopwatchRemove.Elapsed.Ticks);

            // Output sequential scenario results
            var scenario = stopwatchAdd.Elapsed + stopwatchExtremes.Elapsed + stopwatchRemove.Elapsed;
            Debug.Write("," + scenario.Ticks);

            // Setup for random scenario
            Random rand = new Random(1);
            int[] keys = new int[iterations];
            int[] values = new int[iterations];
            int[] indices = Enumerable.Range(0, iterations).ToArray();
            for (int i = 0; i < iterations; i++)
            {
                int j = rand.Next(0, iterations);
                int temp = indices[i];
                indices[i] = indices[j];
                indices[j] = temp;
            }

            // Time entire random scenario
            Stopwatch stopwatchRandom = new Stopwatch();
            for (int i = 0; i < iterations; i++)
            {
                keys[i] = rand.Next();
                values[i] = rand.Next();
            }
            stopwatchRandom.Start();
            for (var i = 0; i < iterations; i++)
            {
                add(keys[i], values[i]);
            }
            for (var i = 0; i < iterations; i++)
            {
                int x = extremes();
            }
            for (var i = 0; i < iterations; i++)
            {
                remove(keys[indices[i]], values[indices[i]]);
            }
            stopwatchRandom.Stop();
            Debug.WriteLine("," + stopwatchRandom.Elapsed.Ticks);

            return scenario;
        }
    }
}
