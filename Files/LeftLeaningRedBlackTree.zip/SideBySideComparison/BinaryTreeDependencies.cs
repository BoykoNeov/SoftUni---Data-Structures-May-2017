﻿using System.Collections.Generic;

namespace System.Windows.Controls.DataVisualization.Collections
{
    static class Dependencies
    {
        /// <summary>
        /// Returns distinct elements from a sorted sequence by using the default equality comparer to compare values.
        /// </summary>
        /// <typeparam name="TSource">The type of the elements of source.</typeparam>
        /// <param name="source">The sequence to remove duplicate elements from.</param>
        /// <returns>An IEnumerable&lt;T&gt; that contains distinct elements from the source sequence.</returns>
        public static IEnumerable<TSource> DistinctOfSorted<TSource>(this IEnumerable<TSource> source)
        {
            IEnumerator<TSource> enumerator = source.GetEnumerator();
            if (enumerator.MoveNext())
            {
                TSource last = enumerator.Current;
                yield return last;
                while (enumerator.MoveNext())
                {
                    if (!enumerator.Current.Equals(last))
                    {
                        last = enumerator.Current;
                        yield return last;
                    }
                }
            }
        }
    }
}
